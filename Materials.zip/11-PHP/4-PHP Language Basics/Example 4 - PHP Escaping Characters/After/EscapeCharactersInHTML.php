
<?php
/*
\n - New Line - <br>
\r - Carriage Return - <br>
\t - Tab - &nbsp;&nbsp;
\$ - Dollar Sign
\" - Double Quotes
\' - Single Quotes
\\ - Single Backslash
*/

    echo 'This isn\'t the way we wanted to printed';

    echo '<br>This is printed on new line<br>';

    echo '<br>We have tab &nbsp;&nbsp; here.<br>';

    echo " This is a \"Special\" character inside the PHP";

