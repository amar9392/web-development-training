<!-- Sample 1 -->
<?php


    echo "This             is                 a                 Test";


