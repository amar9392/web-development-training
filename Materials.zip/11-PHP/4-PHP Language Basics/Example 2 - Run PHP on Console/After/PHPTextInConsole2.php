<!doctype html>
<html>
<head>
    <title>
        PHP in Console
    </title>
</head>
<body>

<h1>Display PHP Code in Console</h1>

    <?php echo "Hello World"; ?>

</body>
</html>