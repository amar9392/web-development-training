<!doctype html>
<html>
<head>
    <title>
        PHP Language Basics
    </title>
</head>
<body>

<h1>Example for PHP Basics</h1>

<p>

    <?php
    echo "PHP is Interesting to work with!<br>";
    ?>

</p>
<hr>

<?=

"
            PHP is a Interpreted Server Side
            
            
            Scripting Language. It is really
            
            
            
            fun to work with PHP!.
        "

?>

<?= 'Did you read the \'PHP Cookbook\' Book?'; ?>

</body>
</html>

