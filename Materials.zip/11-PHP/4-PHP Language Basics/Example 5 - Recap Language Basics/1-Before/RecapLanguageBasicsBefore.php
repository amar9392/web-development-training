<!doctype html>
<html>
<head>
    <title>
        PHP Language Basics
    </title>
</head>
<body>

    <h1>Example for PHP Basics</h1>

</body>
</html>

