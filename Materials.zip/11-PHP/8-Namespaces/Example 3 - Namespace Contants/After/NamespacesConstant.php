<?php

    //namespace is the keyword to define namespace.
    namespace MyNamespaceName;

    //Constants are allowed in namespaces.
    const FILE_NAME = __NAMESPACE__ . "\NamespaceConstants.php" . PHP_EOL;
