<?php


    //namespace is the keyword to define namespace.
    namespace myconstants;

    //Constants are allowed in namespaces.
    const FILE_NAME = "NamespaceConstants.php" . PHP_EOL;