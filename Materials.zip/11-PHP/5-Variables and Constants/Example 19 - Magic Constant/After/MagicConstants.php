<?php

    //https://www.php.net/manual/en/language.constants.predefined.php

    echo __LINE__ . "<br>";
    echo __FILE__;