<?PHP

    //Build in methods are not case sensitive.
    echo 'Hello World!';
    Echo 'Hello World';

    PRINT 'HELLO';


    //Variable are case sensitive
    $name = "PHP!";
    //echo "Name value is: $Name";

    $Name = "Srini";
    echo "Name value is: $name and $Name";


    function print_message() {

        echo "Hello and Welcome to PHP!";

    }

    // Functions are not case-sensitive
    /*
    function PRINT_MESSAGE() {

        echo "Hello and Welcome to PHP!";

    }
    */