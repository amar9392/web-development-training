<!doctype html>
<html>
<head>
    <title>
        Variables and Constants
    </title>
</head>
<body>

	<!-- Sample 1 -->
	<?php
		
		//Define a Variable
		$aboutme = "I am Srini and I love PHP Programming!";
		echo "<h1>About Me:</h1>";
		echo $aboutme; //Printing the Variable

	?>

	<!-- Sample 2 -->
	<?php
		//Change the Variable Value
		$aboutme = "Text is changed to PHP Now!";
		echo $aboutme;
	?>

</body>
</html>

