<?php

/*
 * (condition) ? true : false;
 *
 */


    //Sample 1
    //Ternary Operator
    $flag = (true) ? "Correct" : "Wrong";
    echo $flag . PHP_EOL;
    $flag = (false) ? "Correct" : "Wrong";
    echo $flag . PHP_EOL;

    //Use this in the Comparision Operator
