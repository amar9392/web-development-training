<?php

    //backtick `` - left side to number 1 on keyboard.

    //Windows
    echo `dir *.php`;

    //Linux or Mac
    echo `ls *.php`;