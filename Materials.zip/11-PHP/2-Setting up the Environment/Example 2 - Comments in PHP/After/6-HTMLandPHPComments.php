<!-- This is a HTML Comments -->

<?php
/*
    This is a PHP comments
*/
?>

<!--
<?php

   echo 'Will I be Printed 1?';

?>
-->

<?php

    echo '<!-- Will I be Printed 2? -->';

?>

<?php
/*
?>

Will I be Printed 3

<?php
*/
?>

<!--
<?php
/*
?>

Will I be Printed 4

<?php
*/
?>
-->