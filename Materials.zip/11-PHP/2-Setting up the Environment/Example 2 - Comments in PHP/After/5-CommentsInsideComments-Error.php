<?php

    //This is a Single Line Comment //which is used #to display a #short summary.

    /*
         This is a multi line comments
         /* Another Comments */
        //We can have any number of single line under multi line comments.
        /* Multi Line comments should end correctly like brakets {}. */

    */

?>
