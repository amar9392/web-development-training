<?php
/*
* This Program is used to understand the types of Comments in PHP.
*/
?>

<?= "PHP is Interesting!" /*Comments Here are fine*/ ?>

<?php

    /*
        echo "Welcome to PHP!"; //This is Echo Method
        print "Excited to learn this new Language." #This is Print statement.
    */

?>

