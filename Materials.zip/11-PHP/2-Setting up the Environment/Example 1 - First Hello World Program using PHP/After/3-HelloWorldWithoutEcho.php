<?= "Hello World!"; ?>
<?= 'Hello World!'; ?>

