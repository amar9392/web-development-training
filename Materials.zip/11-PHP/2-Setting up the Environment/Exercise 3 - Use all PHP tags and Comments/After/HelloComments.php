
<?php
/*
This program is to do the following things:
1) Use Multi Line Comments to describe about the program.
2) Use Single line Comments statement to describe the statement
3) Print your Name without echo/print tag.
4) Describe yourself in one line using echo/print.
*/
?>

<?= "My Name is Srini!" //Printing my Name ?>

<?php

    //About me
    echo "I love PHP Web Programming!"

?>
