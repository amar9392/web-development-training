<!doctype html>
<html>
<head>
    <title>
        Data Types
    </title>
</head>
<body>

<h1>Exercise 1: Print Student Details</h1>

<h2>Student Information:</h2>

<h2>Exams Attended and Marks:</h2>

<h2>Final Marks:</h2>

<h2>Percentage:</h2>

<h2>Result:</h2>


</body>
</html>

