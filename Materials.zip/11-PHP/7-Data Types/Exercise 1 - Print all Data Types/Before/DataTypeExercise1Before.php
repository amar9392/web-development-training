<!doctype html>
<html>
<head>
    <title>
        Data Types
    </title>
</head>
<body>

<h1>Exercise 1: Use All Data Types</h1>

<h2>Calculate the area using Length and breath using Integer:</h2>

<h2>Calculate Student Exact Marks Percentage with Double:</h2>

<h2>Check if the user has admin roles:</h2>

<h2>Define and Display a User Name using Strings:</h2>

<h2>Check if the variable is null or not:</h2>


</body>
</html>

